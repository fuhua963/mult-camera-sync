export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:./lib
./bin/X86/consoleDllDemo
