#include "stdio.h"

#include <stdio.h>
#include <string.h>
#include <time.h>
#include "IRSDK.h"
#include <unistd.h>

unsigned short gray[MAX_W * MAX_H];
unsigned char rgb[MAX_W * MAX_H * 3];
unsigned long recv_index = 0;
unsigned int save_index = 0;
char filename[128];
T_DEVICE_INFO sInfo;

int FrameCallBack(void* lData, void* lParam)  //这里仅示例如何将接收到数据转成BGR888, 实际工程中，回调只接收数据，数据处理放到另外的线程，避免阻塞回调
{
    Frame* pFrame = (Frame*)lData;
    printf("index=%d width=%d height=%d center_temp=%.1f\n", recv_index, pFrame->width, pFrame->height, CALTEMP(pFrame->buffer[(pFrame->width + 1) * pFrame->height / 2], pFrame->u8TempDiv));

    IRSDK_Frame2Gray(pFrame, gray, 50, 50, 0);
    IRSDK_Gray2Rgb(gray, rgb, pFrame->width, pFrame->height, 0, 0);

    if (recv_index++ % 300 == 0) //隔几秒保存一个图片
    {
        sprintf(filename, "grab_%03d.jpg", save_index++);
        printf("save jpg: %s\n", filename);
        IRSDK_SaveFrame2Jpeg(filename, pFrame, rgb, 0, NULL);
    }
    if (recv_index == 1)
    {
        int ret = IRSDK_InquireDeviceInfo(0, &sInfo);
        if (!ret)
        {
            printf("Model = %s\n", sInfo.Model);
            printf("IP = %s\n", sInfo.IP);
            printf("Mac = %s\n", sInfo.Mac);
        }
    }
    return 0;
}

int main(void)
{
    CBF_IR pCBFframe = &FrameCallBack;	//回调函数
    T_IPADDR IpInfo[DEVICE_MAX];		//定义接收 ip 信息的数组

    //需要初如化
    IRSDK_Init();
    memset(IpInfo, 0, sizeof(IpInfo)); //清零
    IRSDK_SetIPAddrArray(IpInfo); //设置接收 IP 的空间

#if 0
    while (IpInfo[0].totalOnline == 0) sleep(10000);	//等待自动搜索到相机
#else
    memcpy(IpInfo[0].IPAddr, "192.168.1.13", sizeof("192.168.1.13"));  //手动指定ip
    IpInfo[0].DataPort = 13 * 10 + 30005; //自定义端口
    IpInfo[0].Index = 0;
    IpInfo[0].isValid = 1;
    IpInfo[0].totalOnline = 1;
#endif

    printf("connect ip: %s\n", IpInfo[0].IPAddr);
    int ret =  IRSDK_Create(0, IpInfo[0], pCBFframe, NULL, NULL, NULL);
    printf("ret = %d", ret);
    IRSDK_Connect(0); //连接，连接成功后回调就可以接收到数据

    while (1);
}
