/********************************************************************************
** Form generated from reading UI file 'irmainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.8.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_IRMAINWINDOW_H
#define UI_IRMAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QToolBox>
#include <QtWidgets/QToolButton>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>
#include <playwidget.h>

QT_BEGIN_NAMESPACE

class Ui_IrMainWindow
{
public:
    QWidget *centralwidget;
    QHBoxLayout *horizontalLayout_5;
    PlayWidget *playwidget;
    QVBoxLayout *verticalLayout_2;
    QGroupBox *groupBox;
    QVBoxLayout *verticalLayout;
    QHBoxLayout *horizontalLayout;
    QLabel *label;
    QComboBox *cbox_ip;
    QHBoxLayout *horizontalLayout_2;
    QPushButton *btn_connect;
    QPushButton *btn_disconnect;
    QGroupBox *groupBox_2;
    QVBoxLayout *verticalLayout_3;
    QToolBox *toolBox;
    QWidget *page_3;
    QVBoxLayout *verticalLayout_4;
    QToolButton *toolButton_modifyip;
    QToolButton *toolButton_config;
    QPushButton *btn_calibrate;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *IrMainWindow)
    {
        if (IrMainWindow->objectName().isEmpty())
            IrMainWindow->setObjectName(QStringLiteral("IrMainWindow"));
        IrMainWindow->resize(1120, 733);
        centralwidget = new QWidget(IrMainWindow);
        centralwidget->setObjectName(QStringLiteral("centralwidget"));
        horizontalLayout_5 = new QHBoxLayout(centralwidget);
        horizontalLayout_5->setObjectName(QStringLiteral("horizontalLayout_5"));
        playwidget = new PlayWidget(centralwidget);
        playwidget->setObjectName(QStringLiteral("playwidget"));

        horizontalLayout_5->addWidget(playwidget);

        verticalLayout_2 = new QVBoxLayout();
        verticalLayout_2->setObjectName(QStringLiteral("verticalLayout_2"));
        groupBox = new QGroupBox(centralwidget);
        groupBox->setObjectName(QStringLiteral("groupBox"));
        verticalLayout = new QVBoxLayout(groupBox);
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QStringLiteral("horizontalLayout"));
        label = new QLabel(groupBox);
        label->setObjectName(QStringLiteral("label"));

        horizontalLayout->addWidget(label);

        cbox_ip = new QComboBox(groupBox);
        cbox_ip->setObjectName(QStringLiteral("cbox_ip"));
        cbox_ip->setEnabled(true);
        cbox_ip->setEditable(true);

        horizontalLayout->addWidget(cbox_ip);

        horizontalLayout->setStretch(0, 1);
        horizontalLayout->setStretch(1, 10);

        verticalLayout->addLayout(horizontalLayout);

        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setObjectName(QStringLiteral("horizontalLayout_2"));
        btn_connect = new QPushButton(groupBox);
        btn_connect->setObjectName(QStringLiteral("btn_connect"));

        horizontalLayout_2->addWidget(btn_connect);

        btn_disconnect = new QPushButton(groupBox);
        btn_disconnect->setObjectName(QStringLiteral("btn_disconnect"));

        horizontalLayout_2->addWidget(btn_disconnect);


        verticalLayout->addLayout(horizontalLayout_2);

        groupBox_2 = new QGroupBox(groupBox);
        groupBox_2->setObjectName(QStringLiteral("groupBox_2"));
        verticalLayout_3 = new QVBoxLayout(groupBox_2);
        verticalLayout_3->setObjectName(QStringLiteral("verticalLayout_3"));
        toolBox = new QToolBox(groupBox_2);
        toolBox->setObjectName(QStringLiteral("toolBox"));
        page_3 = new QWidget();
        page_3->setObjectName(QStringLiteral("page_3"));
        page_3->setGeometry(QRect(0, 0, 144, 405));
        verticalLayout_4 = new QVBoxLayout(page_3);
        verticalLayout_4->setObjectName(QStringLiteral("verticalLayout_4"));
        toolButton_modifyip = new QToolButton(page_3);
        toolButton_modifyip->setObjectName(QStringLiteral("toolButton_modifyip"));
        QSizePolicy sizePolicy(QSizePolicy::Minimum, QSizePolicy::Fixed);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(toolButton_modifyip->sizePolicy().hasHeightForWidth());
        toolButton_modifyip->setSizePolicy(sizePolicy);
        toolButton_modifyip->setMinimumSize(QSize(50, 50));

        verticalLayout_4->addWidget(toolButton_modifyip);

        toolButton_config = new QToolButton(page_3);
        toolButton_config->setObjectName(QStringLiteral("toolButton_config"));
        sizePolicy.setHeightForWidth(toolButton_config->sizePolicy().hasHeightForWidth());
        toolButton_config->setSizePolicy(sizePolicy);
        toolButton_config->setMinimumSize(QSize(50, 50));

        verticalLayout_4->addWidget(toolButton_config);

        btn_calibrate = new QPushButton(page_3);
        btn_calibrate->setObjectName(QStringLiteral("btn_calibrate"));
        btn_calibrate->setMinimumSize(QSize(50, 50));

        verticalLayout_4->addWidget(btn_calibrate);

        toolBox->addItem(page_3, QString::fromUtf8("\350\256\276\345\244\207\346\216\247\345\210\266"));

        verticalLayout_3->addWidget(toolBox);


        verticalLayout->addWidget(groupBox_2);

        verticalLayout->setStretch(0, 1);
        verticalLayout->setStretch(1, 1);
        verticalLayout->setStretch(2, 8);

        verticalLayout_2->addWidget(groupBox);

        verticalLayout_2->setStretch(0, 1);

        horizontalLayout_5->addLayout(verticalLayout_2);

        horizontalLayout_5->setStretch(0, 10);
        horizontalLayout_5->setStretch(1, 1);
        IrMainWindow->setCentralWidget(centralwidget);
        menubar = new QMenuBar(IrMainWindow);
        menubar->setObjectName(QStringLiteral("menubar"));
        menubar->setGeometry(QRect(0, 0, 1120, 28));
        IrMainWindow->setMenuBar(menubar);
        statusbar = new QStatusBar(IrMainWindow);
        statusbar->setObjectName(QStringLiteral("statusbar"));
        IrMainWindow->setStatusBar(statusbar);

        retranslateUi(IrMainWindow);

        cbox_ip->setCurrentIndex(-1);
        toolBox->setCurrentIndex(0);


        QMetaObject::connectSlotsByName(IrMainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *IrMainWindow)
    {
        IrMainWindow->setWindowTitle(QApplication::translate("IrMainWindow", "IRdemo_qt", Q_NULLPTR));
        groupBox->setTitle(QApplication::translate("IrMainWindow", "\350\256\276\345\244\207\350\277\236\346\216\245", Q_NULLPTR));
        label->setText(QApplication::translate("IrMainWindow", "IP:", Q_NULLPTR));
        cbox_ip->setCurrentText(QString());
        btn_connect->setText(QApplication::translate("IrMainWindow", "\350\277\236\346\216\245", Q_NULLPTR));
        btn_disconnect->setText(QApplication::translate("IrMainWindow", "\345\201\234\346\255\242", Q_NULLPTR));
        groupBox_2->setTitle(QString());
        toolButton_modifyip->setText(QApplication::translate("IrMainWindow", "\344\277\256\346\224\271IP", Q_NULLPTR));
        toolButton_config->setText(QApplication::translate("IrMainWindow", "\350\256\276\345\244\207\351\205\215\347\275\256", Q_NULLPTR));
        btn_calibrate->setText(QApplication::translate("IrMainWindow", "\345\277\253\351\227\250\350\241\245\345\201\277", Q_NULLPTR));
        toolBox->setItemText(toolBox->indexOf(page_3), QApplication::translate("IrMainWindow", "\350\256\276\345\244\207\346\216\247\345\210\266", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class IrMainWindow: public Ui_IrMainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_IRMAINWINDOW_H
