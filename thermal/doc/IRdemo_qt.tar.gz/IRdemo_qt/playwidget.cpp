#include "playwidget.h"
#include<stdio.h>
#include "irmainwindow.h"

static char * Qstring2char(QString str)
{
    char* ch;
    QByteArray tmp = str.toLatin1();
    ch=tmp.data();
    return ch;
}

int  FrameCallBack(void* lData, void*  lParam)
{
    static int i = 0;
    PlayWidget* pIRPlayer = ((IrMainWindow *)lParam)->playwidget;
    pIRPlayer->framefreq = 0;
    if( pIRPlayer->m_play == false)
        return 0;
    if(pIRPlayer->mutex_bmp.tryLock())
    {
        Frame *tmp = (Frame *)lData;

        pIRPlayer->FrameRecv((Frame *)lData, lParam);
        pIRPlayer->mutex_bmp.unlock();
    }
    return 0;
}

PlayWidget::PlayWidget(QWidget *parent)
    : QWidget(parent)
{
    static QPalette pal;
    static QFont ft("Microsoft YaHei", 10, 75);

    pal.setColor(QPalette::WindowText,Qt::white);

    connect(&timer,SIGNAL(timeout()),this,SLOT(TimeSecond()));

    times = 0;

    pen.setWidth(3);
    pen.setColor(Qt::red);
    pFrame = new Frame;
    pCBFframe = &FrameCallBack;

}


int PlayWidget::FrameConvert(void)
{
    if(pFrame == NULL)
    {
        return -1;
    }

    IRSDK_Frame2Gray(pFrame, m_Covertframe.buffer, 50, 50, 0);
    IRSDK_Gray2Rgb(m_Covertframe.buffer, m_Covertframe.rgb, pFrame->width, pFrame->height, 0, 1);
    IRSDK_Rgb2Bmp(m_Covertframe.bmp, &m_Covertframe.bmpLen, m_Covertframe.rgb, pFrame->width, pFrame->height);

    if (pFrame->u8TriggerFrame == 1)
    {
        QDir dir("image");
        if(!dir.exists()) dir.mkpath("../image");
        m_file = dir.dirName()+"/"+QDate::currentDate().toString("trigger_yyyy.MM.dd")+"-"+ QTime::currentTime().toString("hh.mm.ss.zzz")+".jpg";
        char *path;
        path = Qstring2char(m_file);
        IRSDK_SaveFrame2Jpeg(path,pFrame, m_Covertframe.rgb, 0, NULL);
    }

    return 0;
}


void PlayWidget::TimeSecond()
{


}

int PlayWidget::FrameRecv(Frame* pTmp, void* lParam)
{
    if(pTmp == NULL)
        return -1;

    memcpy(pFrame,pTmp,sizeof(Frame));

    FrameConvert();

    update();
    return 0;

}

int PlayWidget::Play()
{
    IRSDK_Play(0);

    m_play = true;
    timer.start(250);

    Irstop = 0;
    return 0;
}


void PlayWidget::paintEvent(QPaintEvent *)
{
    if(m_play == true)
    {
        QPainter painterImage(this);
        QRect rect_image(0,0,this->width(),this->height());
        QImage pixImg;
        mutex_bmp.lock();
        pixImg.loadFromData((unsigned char *)&m_Covertframe.bmp[0],m_Covertframe.bmpLen,0);

        painterImage.drawImage(rect_image,pixImg);

        mutex_bmp.unlock();
        painterImage.end();
    }

    return ;

}

PlayWidget::~PlayWidget()
{
    if(pFrame !=NULL)
        free(pFrame);
    pFrame = NULL;
}

