#ifndef FORM_CONFIG_H
#define FORM_CONFIG_H

#include <QWidget>
#include "IRSDK.h"

namespace Ui {
class Form_Config;
}

class Form_Config : public QWidget
{
    Q_OBJECT

public:
    explicit Form_Config(QWidget *parent = 0);
    ~Form_Config();

private slots:
    void on_checkBox_auto_toggled(bool checked);

    void on_comboBox_divfps_currentIndexChanged(int index);

    void on_toolButton_saveconfig_clicked();

private:
    Ui::Form_Config *ui;
};

#endif // FORM_CONFIG_H
