/********************************************************************************
** Form generated from reading UI file 'form_config.ui'
**
** Created by: Qt User Interface Compiler version 5.8.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_FORM_CONFIG_H
#define UI_FORM_CONFIG_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QFrame>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QToolButton>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Form_Config
{
public:
    QVBoxLayout *verticalLayout_2;
    QFrame *frame;
    QVBoxLayout *verticalLayout;
    QCheckBox *checkBox_auto;
    QComboBox *comboBox_divfps;
    QToolButton *toolButton_saveconfig;

    void setupUi(QWidget *Form_Config)
    {
        if (Form_Config->objectName().isEmpty())
            Form_Config->setObjectName(QStringLiteral("Form_Config"));
        Form_Config->resize(145, 120);
        verticalLayout_2 = new QVBoxLayout(Form_Config);
        verticalLayout_2->setObjectName(QStringLiteral("verticalLayout_2"));
        frame = new QFrame(Form_Config);
        frame->setObjectName(QStringLiteral("frame"));
        frame->setFrameShape(QFrame::StyledPanel);
        frame->setFrameShadow(QFrame::Raised);
        verticalLayout = new QVBoxLayout(frame);
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        checkBox_auto = new QCheckBox(frame);
        checkBox_auto->setObjectName(QStringLiteral("checkBox_auto"));

        verticalLayout->addWidget(checkBox_auto);

        comboBox_divfps = new QComboBox(frame);
        comboBox_divfps->setObjectName(QStringLiteral("comboBox_divfps"));

        verticalLayout->addWidget(comboBox_divfps);

        toolButton_saveconfig = new QToolButton(frame);
        toolButton_saveconfig->setObjectName(QStringLiteral("toolButton_saveconfig"));
        QSizePolicy sizePolicy(QSizePolicy::Preferred, QSizePolicy::Preferred);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(toolButton_saveconfig->sizePolicy().hasHeightForWidth());
        toolButton_saveconfig->setSizePolicy(sizePolicy);

        verticalLayout->addWidget(toolButton_saveconfig);


        verticalLayout_2->addWidget(frame);


        retranslateUi(Form_Config);

        QMetaObject::connectSlotsByName(Form_Config);
    } // setupUi

    void retranslateUi(QWidget *Form_Config)
    {
        Form_Config->setWindowTitle(QApplication::translate("Form_Config", "Form", Q_NULLPTR));
        checkBox_auto->setText(QApplication::translate("Form_Config", "\350\207\252\345\212\250\345\270\247\351\242\221", Q_NULLPTR));
        comboBox_divfps->clear();
        comboBox_divfps->insertItems(0, QStringList()
         << QApplication::translate("Form_Config", "/1", Q_NULLPTR)
         << QApplication::translate("Form_Config", "/2", Q_NULLPTR)
         << QApplication::translate("Form_Config", "/4", Q_NULLPTR)
         << QApplication::translate("Form_Config", "/8", Q_NULLPTR)
         << QApplication::translate("Form_Config", "/16", Q_NULLPTR)
         << QApplication::translate("Form_Config", "/32", Q_NULLPTR)
        );
        toolButton_saveconfig->setText(QApplication::translate("Form_Config", "\344\277\235\345\255\230\351\205\215\347\275\256", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class Form_Config: public Ui_Form_Config {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_FORM_CONFIG_H
