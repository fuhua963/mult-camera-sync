#include "form_config.h"
#include "ui_form_config.h"

Form_Config::Form_Config(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Form_Config)
{
    ui->setupUi(this);
}

Form_Config::~Form_Config()
{
    delete ui;
}

void Form_Config::on_checkBox_auto_toggled(bool checked)
{
    IRSDK_Command(0, 4471, checked);
}

void Form_Config::on_comboBox_divfps_currentIndexChanged(int index)
{
    int fps[6] = {0, 2, 4, 8, 16, 32};
    IRSDK_Command(0, 4473, fps[index]);
}

void Form_Config::on_toolButton_saveconfig_clicked()
{
    IRSDK_Command(0, 4234, 4);
}
