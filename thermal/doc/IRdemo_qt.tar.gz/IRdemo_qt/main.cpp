#include <QTextCodec>
#include <QtGui/QGuiApplication>
#include "irmainwindow.h"
int main(int argc, char *argv[])
{
	//QGuiApplication app(argc, argv); 
	QApplication app(argc, argv); 
	QTextCodec *codec = QTextCodec::codecForName("GBK");

    QTranslator aTranslator;
    aTranslator.load("project_CN.qm");
    app.installTranslator(&aTranslator);

	IrMainWindow w;
	w.show();
	return app.exec();
}
