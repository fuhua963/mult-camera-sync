#ifndef _IRMAINWINDOW_H
#define _IRMAINWINDOW_H

#include <QtWidgets/QMainWindow>
#include <QtWidgets/QPushButton>

#include "IRSDK.h"
#include "ui_irmainwindow.h"
#include "form_config.h"

class IrMainWindow : public QMainWindow,public Ui_IrMainWindow
{
	Q_OBJECT
public:

    IrMainWindow(QWidget *parent = 0);
    ~IrMainWindow();
    friend int CmdCallBack(void* lData, void* lParam);
    void AddIp2Item(T_IPADDR *pIpInfo);
	CBF_IR pCBFcmd;
    CBF_IR pCBFcomm;
	CBF_IR pCBFframe;
    CBF_IR pCBFreply;

    QTimer TimerMonitor;
    quint8 u8Online[DEVICE_MAX];
     QMutex mutex_itemIP;
     int totalIp = 0;
     int lasttotalIp = 0;
public slots:
    int Connect();
    int Calibrate();
    int Monitor();
    int Stop();
    void TimeSecond();
    void modify_ip();
    void config();
private:
	QString ir_ip;
    QTimer timesend;

    Form_Config _config;
};

#endif
