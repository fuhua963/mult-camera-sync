#include "irmainwindow.h"

T_IPADDR IPADDR_IR[DEVICE_MAX];

int CmdCallBack(void* lData, void* lParam)
{
	return 0;
}

int CommCallBack(void* lData, void* lParam)
{
    return 0;
}

int  ReplyCallBack(void* lData, void* lParam)
{
    return 0;
}

IrMainWindow::IrMainWindow(QWidget *parent): QMainWindow(parent)
{
    this->setWindowTitle("IRdemo_qt");
    static QPalette pal;
    static QFont ft("Microsoft YaHei", 10, 75);
    pal.setColor(QPalette::WindowText,Qt::white);

    setupUi(this);

    memset(u8Online, 0, DEVICE_MAX);
    u8Online[0] = 255; //keep the item0
    TimerMonitor.setInterval(500);
    TimerMonitor.start();
    connect(&TimerMonitor,SIGNAL(timeout()),this,SLOT(Monitor()));
    mutex_itemIP.unlock();
    pCBFcmd = &CmdCallBack;
    pCBFcomm = &CommCallBack;
    pCBFframe = playwidget->pCBFframe;
    pCBFreply = &ReplyCallBack;

    IRSDK_Init();
    IRSDK_SetIPAddrArray(IPADDR_IR);

    connect(btn_connect,SIGNAL(clicked()),this,SLOT(Connect()));
    connect(&timesend,SIGNAL(timeout()),this,SLOT(TimeSecond()));
    connect(btn_calibrate,SIGNAL(clicked()),this,SLOT(Calibrate()));
    connect(btn_disconnect,SIGNAL(clicked()),this,SLOT(Stop()));
    connect(toolButton_modifyip,SIGNAL(clicked()),this,SLOT(modify_ip()));
    connect(toolButton_config, SIGNAL(clicked()), this, SLOT(config()));
    timesend.start(1000);

}
int IrMainWindow::Stop()
{
    return IRSDK_Stop(0);
}
void IrMainWindow::TimeSecond()
{

}

int IrMainWindow::Connect()
{
    QString str;

    str = cbox_ip->lineEdit()->text();
    if(str.isEmpty())
    {
        QMessageBox::information(this,tr("Tips"),tr("Please Connect the Camera First!!!"), tr("OK"));
        return 0;
    }
    ir_ip=cbox_ip->currentText();

    char strIp[32];
    QByteArray dome2 = ir_ip.toLocal8Bit();
    strcpy(strIp, dome2.data());

    quint8 u8Find = 0;
    T_IPADDR IpInfo;
    for(int i = 0; i< IPADDR_IR[0].totalOnline; i++)
    {
        if (!strcmp((const char *)(&strIp[0]), (const char *)(&(IPADDR_IR[i].IPAddr[0]))))
        {
            IpInfo = IPADDR_IR[i];
            u8Find = 1;
            break;
        }
    }

    if (u8Find == 0)
    {
        memcpy(IpInfo.IPAddr ,strIp, sizeof(strIp));
        QStringList strlist = ir_ip.split(".");
        IpInfo.DataPort = strlist.at(3).toInt() * 10 + 30005;
        IpInfo.isValid = 1;
    }

    IRSDK_Create(0, IpInfo, pCBFframe, pCBFcmd, pCBFcomm, (void *)(this));
    IRSDK_Connect(0);

    this->playwidget->Play();

    return 0;
}


int IrMainWindow::Calibrate()
{
    return	IRSDK_Calibration(0);
}

void IrMainWindow::modify_ip()
{
    QString ip = cbox_ip->currentText();
    IRSDK_SetIP(0, ip.toLatin1().data());
    cbox_ip->clear();
}

IrMainWindow::~IrMainWindow()
{
    IRSDK_Quit();
}

void IrMainWindow::AddIp2Item(T_IPADDR *pIpInfo)
{
#define TIMEOUT         3
    QString strItem;

    totalIp = pIpInfo->totalOnline;

    if(totalIp != lasttotalIp)
    {
        cbox_ip->clear();
        for(int i = 0; i < totalIp; i++)
        {
            strItem = QString(QLatin1String(pIpInfo[i].IPAddr));
            cbox_ip->addItem(strItem);
        }
        lasttotalIp = totalIp;
    }
}

int IrMainWindow::Monitor()
{

    if (0 ==  IRSDK_IsConnected(0))
    {
        IRSDK_Connect(0);
    }

    AddIp2Item(IPADDR_IR);  //add ip

    return 0;
}

void IrMainWindow::config()
{
    _config.show();
}
